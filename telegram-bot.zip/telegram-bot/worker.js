import { Telegraf } from 'telegraf';
import config from './config.json';

const bot = new Telegraf(config.BOT_TOKEN);

bot.on('message', async (ctx) => {
  try {
    const channels = [config.CHANNEL_ID_1, config.CHANNEL_ID_2];

    for (const ch of channels) {
      if (ctx.message.photo) {
        await ctx.telegram.sendPhoto(ch, ctx.message.photo[0].file_id, { caption: ctx.message.caption || '' });
      } else if (ctx.message.video) {
        await ctx.telegram.sendVideo(ch, ctx.message.video.file_id, { caption: ctx.message.caption || '' });
      } else if (ctx.message.sticker) {
        await ctx.telegram.sendSticker(ch, ctx.message.sticker.file_id);
      } else if (ctx.message.text) {
        await ctx.telegram.sendMessage(ch, ctx.message.text);
      }
    }
  } catch (e) {
    console.error(e);
  }
});

bot.launch();
